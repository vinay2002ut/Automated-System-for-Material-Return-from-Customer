<?php

@include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:login.php');
}
;

if (isset($_POST['update_order'])) {

    $order_id = $_POST['order_id'];
    $update_payment = $_POST['update_payment'];
    $update_payment = filter_var($update_payment, FILTER_SANITIZE_STRING);
    $update_orders = $conn->prepare("UPDATE `orders` SET payment_status = ? WHERE id = ?");
    $update_orders->execute([$update_payment, $order_id]);
    $message[] = 'payment has been updated!';

}
;

if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_orders = $conn->prepare("DELETE FROM `orders` WHERE id = ?");
    $delete_orders->execute([$delete_id]);
    header('location:admin_orders.php');
}

?>














<!DOCTYPE html>
<html lang="en" dir="ltr">


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/order-list.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Oct 2023 03:23:23 GMT -->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Fastkart admin is super flexible, powerful, clean &amp; modern responsive bootstrap 5 admin template with unlimited possibilities.">
    <meta name="keywords"
        content="admin template, Fastkart admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="pixelstrap">
    <link rel="icon" href="assets/images/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
    <title>Fastkart - Order List</title>

    <!-- Google font-->
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
        rel="stylesheet">

    <!-- Fontawesome css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/font-awesome.css">

    <!-- Linear Icon -->
    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">

    <!-- Themify icon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/themify.css">

    <!-- Feather icon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/feather-icon.css">

    <!-- remixicon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/remixicon.css">

    <!-- Data Table css -->
    <link rel="stylesheet" type="text/css" href="assets/css/datatables.css">

    <!-- Plugins css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/scrollbar.css">
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/animate.css">

    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/bootstrap.css">

    <!-- App css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">









    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/admin_style.css">





</head>

<body>
    <!-- tap on top start-->
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>
    <!-- tap on tap end-->

















    <script src="js/script.js"></script>








    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <!-- Page Header Start-->
        <?php include 'admin_head.php'; ?>
        <!-- Page Header Ends-->

        <!-- Page Body Start-->
        <div class="page-body-wrapper">
            <!-- Page Sidebar Start-->
            <?php include 'sidebar.php'; ?>
            <!-- Page Sidebar Ends-->

            <!-- Order section Start -->
            <div class="page-body">








                <section class="placed-orders">

                    <h1 class="title">placed orders</h1>

                    <div class="box-container">

                        <?php
                        $select_orders = $conn->prepare("SELECT * FROM `orders`");
                        $select_orders->execute();
                        if ($select_orders->rowCount() > 0) {
                            while ($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                <div class="box">
                                    <p> user id : <span>
                                            <?= $fetch_orders['user_id']; ?>
                                        </span> </p>
                                    <p> placed on : <span>
                                            <?= $fetch_orders['placed_on']; ?>
                                        </span> </p>
                                    <p> name : <span>
                                            <?= $fetch_orders['name']; ?>
                                        </span> </p>
                                    <p> email : <span>
                                            <?= $fetch_orders['email']; ?>
                                        </span> </p>
                                    <p> number : <span>
                                            <?= $fetch_orders['number']; ?>
                                        </span> </p>
                                    <p> address : <span>
                                            <?= $fetch_orders['address']; ?>
                                        </span> </p>
                                    <p> total products : <span>
                                            <?= $fetch_orders['total_products']; ?>
                                        </span> </p>
                                    <p> total price : <span>
                                            <?php $rupeeSymbol = "\u{20B9}";
                                            echo "{$rupeeSymbol}";
                                            ?>
                                            <?= $fetch_orders['total_price']; ?>/-
                                        </span> </p>
                                    <p> payment method : <span>
                                            <?= $fetch_orders['method']; ?>
                                        </span> </p>
                                    <form action="" method="POST">
                                        <input type="hidden" name="order_id" value="<?= $fetch_orders['id']; ?>">
                                        <select name="update_payment" class="drop-down">
                                            <option value="" selected disabled>
                                                <?= $fetch_orders['payment_status']; ?>
                                            </option>
                                            <option value="pending">pending</option>
                                            <option value="completed">completed</option>
                                        </select>
                                        <div class="flex-btn">
                                            <input type="submit" name="update_order" class="option-btn" value="udate">
                                            <a href="admin_orders.php?delete=<?= $fetch_orders['id']; ?>" class="delete-btn"
                                                onclick="return confirm('delete this order?');">delete</a>
                                        </div>
                                    </form>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p class="empty">no orders placed yet!</p>';
                        }
                        ?>

                    </div>

                </section>















                <!-- Table Start -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card card-table">
                                <div class="card-body">
                                    <div class="title-header option-title">
                                        <h5>Order List</h5>
                                        <!-- <a href="#" class="btn btn-solid">Download all orders</a> -->
                                    </div>
                                </div>
                                <?php
                                $select_orders = $conn->prepare("SELECT * FROM `orders`");
                                $select_orders->execute();
                                if ($select_orders->rowCount() > 0) {
                                    ?>
                                    <div class="table-responsive">
                                        <table class="table all-package order-table theme-table" id="table_id">
                                            <thead>
                                                <tr>
                                                    <th>User_id</th>
                                                    <th>Placed On</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Number</th>
                                                    <th>Address</th>
                                                    <th>Total Products</th>
                                                    <th>Total Price</th>
                                                    <th>Payment Method</th>
                                                    <th>Payment Status</th>
                                                    <th>Option</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php
                                                while ($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)) {
                                                    ?>
                                                    <tr data-bs-toggle="offcanvas" href="#order-details">
                                                        <td>
                                                            <?= $fetch_orders['user_id']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['placed_on']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['name']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['email']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['number']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['address']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['total_products']; ?>
                                                        </td>
                                                        <td>
                                                            <?php $rupeeSymbol = "\u{20B9}";
                                                            echo "{$rupeeSymbol}"; ?>
                                                            <?= $fetch_orders['total_price']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['method']; ?>
                                                        </td>
                                                        <td>
                                                            <?= $fetch_orders['payment_status']; ?>
                                                        </td>
                                                        <td>
                                                            <ul>
                                                                <li>
                                                                    <!-- Add the appropriate link for viewing order details -->
                                                                    <a href="order-detail.html">
                                                                        <i class="ri-eye-line"></i>
                                                                    </a>
                                                                </li>

                                                                <li>
                                                                    <!-- Add the appropriate link for editing the order -->
                                                                    <a href="javascript:void(0)">
                                                                        <i class="ri-pencil-line"></i>
                                                                    </a>
                                                                </li>

                                                                <li>
                                                                    <!-- Add the appropriate link for deleting the order -->
                                                                    <a href="javascript:void(0)" data-bs-toggle="modal"
                                                                        data-bs-target="#exampleModalToggle">
                                                                        <i class="ri-delete-bin-line"></i>
                                                                    </a>
                                                                </li>

                                                                <li>
                                                                    <!-- Add the appropriate link for order tracking -->
                                                                    <a class="btn btn-sm btn-solid text-white"
                                                                        href="order-tracking.html">
                                                                        Tracking
                                                                    </a>
                                                                </li>

                                                            </ul>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php
                                } else {
                                    echo '<p class="empty">No orders placed yet!</p>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Table End -->

        <!-- footer start-->
        <div class="container-fluid">
            <footer class="footer">
                <div class="row">
                    <div class="col-md-12 footer-copyright text-center">
                        <p class="mb-0">Copyright 2022 © Fastkart theme by pixelstrap</p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <!-- Order section End -->
    </div>
    <!-- Page Body End-->
    </div>
    <!-- page-wrapper End -->

    <!-- Modal start -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog  modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <h5 class="modal-title" id="staticBackdropLabel">Logging Out</h5>
                    <p>Are you sure you want to log out?</p>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <div class="button-box">
                        <button type="button" class="btn btn--no" data-bs-dismiss="modal">No</button>
                        <button type="button" class="btn  btn--yes btn-primary">Yes</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal end -->

    <!-- Delete Modal Box Start -->
    <div class="modal fade theme-modal remove-coupon" id="exampleModalToggle" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-block text-center">
                    <h5 class="modal-title w-100" id="exampleModalLabel22">Are You Sure ?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="remove-box">
                        <p>The permission for the use/group, preview is inherited from the object, object will create a
                            new permission for this object</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-animation btn-md fw-bold" data-bs-dismiss="modal">No</button>
                    <button type="button" class="btn btn-animation btn-md fw-bold" data-bs-target="#exampleModalToggle2"
                        data-bs-toggle="modal" data-bs-dismiss="modal">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade theme-modal remove-coupon" id="exampleModalToggle2" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="exampleModalLabel12">Done!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="remove-box text-center">
                        <div class="wrapper">
                            <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                                <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none" />
                                <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
                            </svg>
                        </div>
                        <h4 class="text-content">It's Removed.</h4>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Modal Box End -->

    <!-- Offcanvas Box Start -->
    <div class="offcanvas offcanvas-end order-offcanvas" tabindex="-1" id="order-details"
        aria-labelledby="offcanvasExampleLabel" aria-expanded="false">
        <div class="offcanvas-header">
            <h4 class="offcanvas-title" id="offcanvasExampleLabel">#573-685572</h4>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="offcanvas-body">
            <div class="order-date">
                <h6>September 17, 2022 <span class="ms-3">8:12 PM</span></h6>
                <a href="javascript:void(0)" class="d-block mt-1">Cancel Order</a>
            </div>

            <div class="accordion accordion-flush custome-accordion" id="accordionFlushExample">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                            Status
                        </button>
                    </h2>
                    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body">
                            <ul class="status-list">
                                <li>
                                    <a value="pending" href="javascript:void(0)">pending</a>
                                </li>
                                <li>
                                    <a value="completed" href="javascript:void(0)">completed</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Order update form -->
            <form method="post" action="admin_orders.php">
                <input type="hidden" name="order_id" value="<?= $fetch_orders['id']; ?>">
                <select name="update_payment" class="drop-down">
                    <option value="" selected disabled>
                        <?= $fetch_orders['payment_status']; ?>
                    </option>
                    <option value="pending">pending</option>
                    <option value="completed">completed</option>
                </select>
                <div class="flex-btn">
                    <input type="submit" name="update_order" class="option-btn" value="update">
                    <a href="admin_orders.php?delete=<?= $fetch_orders['id']; ?>" class="delete-btn"
                        onclick="return confirm('delete this order?');">delete</a>
                </div>
            </form>
        </div>
    </div>
    <!-- Offcanvas Box End -->

    <!-- latest js -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap js -->
    <script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>

    <!-- feather icon js -->
    <script src="assets/js/icons/feather-icon/feather.min.js"></script>
    <script src="assets/js/icons/feather-icon/feather-icon.js"></script>

    <!-- scrollbar simplebar js -->
    <script src="assets/js/scrollbar/simplebar.js"></script>
    <script src="assets/js/scrollbar/custom.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/sidebar-menu.js"></script>
    <script src="assets/js/notify/bootstrap-notify.min.js"></script>
    <script src="assets/js/notify/index.js"></script>

    <!-- Apexchar js -->
    <script src="assets/js/chart/apex-chart/apex-chart1.js"></script>
    <script src="assets/js/chart/apex-chart/moment.min.js"></script>
    <script src="assets/js/chart/apex-chart/apex-chart.js"></script>
    <script src="assets/js/chart/apex-chart/stock-prices.js"></script>
    <script src="assets/js/chart/apex-chart/chart-custom1.js"></script>




</body>


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/order-list.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Oct 2023 03:23:31 GMT -->

</html>