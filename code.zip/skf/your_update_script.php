if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    $action = $_POST['action'];
    $device_id = $_POST['device_id']; // Get the device ID
console.log(device_id); 
    // Check if the user provided a device ID
    if (!empty($device_id)) {
        // Update the order status and device ID in the database
        $sql = "UPDATE orders SET payment_status = 'delivered', device_id = :device_id WHERE id = :order_id";
        $stmt = $conn->prepare($sql);
        if ($stmt->execute([':order_id' => $order_id, ':device_id' => $device_id])) {
            echo "Order $order_id has been marked as delivered with device ID: $device_id.";
        } else {
            echo "Error marking order $order_id as delivered.";
        }
    } else {
        echo "Please provide a valid device ID.";
    }
    exit;
}
