<?php
$host = "localhost";
$db_name = "shop_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die(); // Terminate the script if the connection fails
}

session_start();
$delivery_id = $_SESSION['delivery_id'];
if (!isset($delivery_id)) {
    header('location: login.php');
    exit;
}

// Check if a form has been submitted
// Check if a form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    $action = $_POST['action'];
    $dev_id = $_POST['dev_id']; // Get the updated device_id

    if ($action === 'cancel') {
        // Update the order status to 'cancelled' and the device_id in the database
        $sql = "UPDATE orders SET payment_status = 'cancelled', device_id = :dev_id WHERE id = :order_id";
        $stmt = $conn->prepare($sql);
        if ($stmt->execute([':order_id' => $order_id, ':dev_id' => $dev_id])) {
            echo "Order $order_id has been cancelled and device_id updated.";
        } else {
            echo "Error cancelling order $order_id or updating device_id.";
        }
    } elseif ($action === 'delivered') {
        // Update the order status to 'delivered' and the device_id in the database
        $sql = "UPDATE orders SET payment_status = 'delivered', device_id = :dev_id WHERE id = :order_id";
        $stmt = $conn->prepare($sql);
        if ($stmt->execute([':order_id' => $order_id, ':dev_id' => $dev_id])) {
            echo "Order $order_id has been marked as delivered and device_id updated.";
        } else {
            echo "Error marking order $order_id as delivered or updating device_id.";
        }
    } elseif ($action === 'return') {

        // Create an SQL query with a placeholder for the device ID
        $sql = "SELECT device_id FROM orders WHERE device_id = :dev_id";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        // Bind the parameter
        $stmt->bindParam(':dev_id', $dev_id, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Fetch the result
        $result = $stmt->fetch();

        if ($result) {
            echo "Product ID is matched";
            $sql = "UPDATE orders SET payment_status = 'return', device_id = :dev_id WHERE id = :order_id";
            $stmt = $conn->prepare($sql);
            if ($stmt->execute([':order_id' => $order_id, ':dev_id' => $dev_id])) {
                echo "Order $order_id has been marked as return and device_id updated.";
            } else {
                echo "Error marking order $order_id as return or updating device_id.";
            }
        } else {
            echo "Product ID is not matched";
        }

    }
    // Exit to prevent the page from reloading after the form submission
    //exit;
}

// Create a SQL query to fetch orders only when the page is initially loaded
$sql = "SELECT * FROM orders";
try {
    $result = $conn->query($sql);

    if ($result) {
        $data = $result->fetchAll(PDO::FETCH_ASSOC);
    } else {
        die("Error in SQL query: " . $conn->errorInfo()[2]);
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
// Close the database connection when done
$conn = null;
?>
<!DOCTYPE html>
<html>

<head>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/admin_style.css">
    <!-- fontawesome css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/font-awesome.css">

    <!-- remixicon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/remixicon.css">

    <!-- Plugins css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/scrollbar.css">
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/animate.css">

    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/bootstrap.css">

    <!-- App css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <style>
        table {
            margin: 10px;
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        button {
            background-color: gray;
            color: white;
            padding: 3px;
            margin: 7px;
        }

        input[type=text] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        @import url('https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600&display=swap');

        :root {
            --green: #27ae60;
            --orange: #f39c12;
            --red: #e74c3c;
            --black: #333;
            --light-color: #666;
            --white: #fff;
            --light-bg: #f6f6f6;
            --border: .2rem solid var(--black);
            --box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .1);
        }

        * {
            font-family: 'Rubik', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
            color: var(--black);
        }

        *::selection {
            background-color: var(--green);
            color: var(--white);
        }

        *::-webkit-scrollbar {
            height: .5rem;
            width: 1rem;
        }

        *::-webkit-scrollbar-track {
            background-color: transparent;
        }

        *::-webkit-scrollbar-thumb {
            background-color: var(--green);
        }

        body {
            background-color: var(--light-bg);
            /* padding-bottom: 6.5rem; */
        }

        html {
            font-size: 62.5%;
            overflow-x: hidden;
            scroll-behavior: smooth;
            scroll-padding-top: 6.5rem;
        }
    </style>
</head>

<body>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            .navbar a {
                text-decoration: none !important;
            }
        </style>
    </head>

    <body>


        <header class="header">

            <div class="flex">

                <a href="home.php" class="logo">skf<span>.</span></a>

                <nav class="navbar">
                    <a href="home.php">Refresh</a>
                </nav>

                <div class="icons">
                    <div id="menu-btn" class="fas fa-bars"></div>
                    <div id="user-btn" class="fas fa-user"></div>
                </div>

                <div class="profile">
                    <img src="uploaded_img/" alt="">
                    <p></p>
                    <a href="logout.php" class="delete-btn">Logout</a>
                </div>
            </div>

        </header>


        <div class="home-bg">
            <table style="display: flex; width:98%; min-height: 200px; border: 1px solid black;">
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Number</th>
                    <th>Email</th>
                    <th>Method</th>
                    <th>Address</th>
                    <th>Total Products</th>
                    <th>Total Price</th>
                    <th>Placed On</th>
                    <th>Status</th>
                    <th>Product ID</th>
                    <th>update status</th>
                </tr>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <td>
                            <?= $row['id'] ?>
                        </td>
                        <td>
                            <?= $row['user_id'] ?>
                        </td>
                        <td>
                            <?= $row['name'] ?>
                        </td>
                        <td>
                            <?= $row['number'] ?>
                        </td>
                        <td>
                            <?= $row['email'] ?>
                        </td>
                        <td>
                            <?= $row['method'] ?>
                        </td>
                        <td>
                            <?= $row['address'] ?>
                        </td>
                        <td>
                            <?= $row['total_products'] ?>
                        </td>
                        <td>
                            <?= $row['total_price'] ?>
                        </td>
                        <td>
                            <?= $row['placed_on'] ?>
                        </td>
                        <td>
                            <?= $row['payment_status'] ?>
                        </td>
                        <td>
                            <?= $row['device_id'] ?>
                        </td>
                        <td>
                            <form class="order-form" data-order-id="<?= $row['id'] ?>" action="" method="post">
                                <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                                <input type="text" name="dev_id" val="<?= $row['delivery_id'] ?>" required>
                                <button type="submit" name="action" value="cancel">Cancel</button>
                                <button type="submit" name="action" value="delivered">Delivered</button>
                                <button type="submit" name="action" value="return">Return</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>


        </div>

        <script src="js/script.js"></script>

        <script>// '.tbl-content' consumed little space for vertical scrollbar, scrollbar width depend on browser/os/platfrom. Here calculate the scollbar width .
            $(window).on("load resize ", function () {
                var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
                $('.tbl-header').css({ 'padding-right': scrollWidth });
            }).resize();</script>
    </body>

</html>