<?php
$host = "localhost"; // Change this to your database host
$db_name = "shop_db"; // Change this to your database name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
