<?php
	if (!empty($_SERVER['HTTP']) && ('on' == $_SERVER['HTTP'])) {
		$uri = 'http://';
	} else {
		$uri = 'http://';
	}
	$uri .= $_SERVER['HTTP_HOST'];
	header('Location: '.$uri.'/dashboard/');
	exit;
?>
Something is wrong with the XAMPP installation :-(
