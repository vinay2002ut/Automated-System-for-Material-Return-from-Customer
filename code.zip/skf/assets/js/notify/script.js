        'use strict';

        // Function to show notification
        function showNotification(message) {
            // Replace this with your actual notification display logic
            alert(message);
        }

        // Attach a click event listener to the button
        document.getElementById('showNotification').addEventListener('click', function (event) {
            // Prevent the default form submission behavior
            event.preventDefault();

            // Assuming you are using AJAX to submit the form
            var formData = new FormData(document.querySelector('form'));

            fetch('admin_add_new_products.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Check if the product was added successfully
                if (data.success) {
                    // Product added successfully, show the notification
                    showNotification(data.notification);
                    // Optionally, you can refresh the page after successful addition
                    location.reload();
                } else {
                    // Product addition failed, show an error notification
                    showNotification(data.notification);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                // Handle the error as needed
            });
        });
